-- Supabase PostgreSQL schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'طالب',
  grade text not null default 'الثالث المتوسط',
  created_at timestamptz not null default now()
);
create table if not exists public.backlogs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null, title text not null,
  lessons int not null default 0 check (lessons >= 0),
  pages int not null default 0 check (pages >= 0),
  lectures int not null default 0 check (lectures >= 0),
  due_date date, status text not null default 'لم يبدأ'
    check (status in ('لم يبدأ','قيد الدراسة','مكتمل')),
  created_at timestamptz not null default now()
);
create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null, document jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
create table if not exists public.exam_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text, score int not null, total int not null,
  answers jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);
create table if not exists public.flashcards (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  question text not null, answer text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.study_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null, is_done boolean not null default false,
  due_at timestamptz, created_at timestamptz not null default now()
);
create table if not exists public.mistakes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  question text not null, correct_answer text, explanation text,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.backlogs enable row level security;
alter table public.notes enable row level security;
alter table public.exam_attempts enable row level security;
alter table public.flashcards enable row level security;
alter table public.study_tasks enable row level security;
alter table public.mistakes enable row level security;
create policy "profile owner only" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "backlogs owner only" on public.backlogs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "notes owner only" on public.notes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "exam attempts owner only" on public.exam_attempts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "flashcards owner only" on public.flashcards for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "study tasks owner only" on public.study_tasks for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "mistakes owner only" on public.mistakes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
