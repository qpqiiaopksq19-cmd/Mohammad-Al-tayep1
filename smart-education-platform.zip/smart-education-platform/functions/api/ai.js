export async function onRequestPost({ request, env }) {
  const origin = request.headers.get("Origin") || "";
  const allowed = (env.ALLOWED_ORIGIN || "").split(",").map(x => x.trim()).filter(Boolean);
  if (allowed.length && !allowed.includes(origin)) return new Response("Forbidden", { status: 403 });
  if (!env.AI_API_KEY) return Response.json({ error: "AI service is not configured" }, { status: 503 });
  const ip = request.headers.get("CF-Connecting-IP") || "unknown";
  // Add a Cloudflare Rate Limiting rule for /api/ai in the dashboard as well.
  const body = await request.json().catch(() => null);
  if (!body || typeof body.message !== "string" || body.message.length > 6000) {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }
  const system = "أنت المعلم الذكي لمنصة تعليمية لطلاب الثالث المتوسط في العراق. اشرح ببساطة وبالعربية عند الحاجة، وراعِ مستوى الطالب. في وضع memory لا تكشف الإجابة قبل محاولة الطالب.";
  const upstream = await fetch(env.AI_API_URL || "https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Authorization": `Bearer ${env.AI_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: env.AI_MODEL || "gpt-4o-mini",
      messages: [{ role: "system", content: system }, { role: "user", content: `[mode:${body.mode || "chat"}] ${body.message}` }],
      temperature: 0.4, max_tokens: 900
    })
  });
  if (!upstream.ok) return Response.json({ error: "AI provider request failed" }, { status: 502 });
  const data = await upstream.json();
  return Response.json({ reply: data.choices?.[0]?.message?.content || "لم أتمكن من تكوين إجابة." });
}
